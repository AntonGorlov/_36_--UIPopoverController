//
//  ViewController.h
//  UIPopoverController (Lesson 36)
//
//  Created by Anton Gorlov on 10.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)actionPressMe:(UIButton *)sender;

- (IBAction)actionAdd:(UIBarButtonItem *)sender;


@end

