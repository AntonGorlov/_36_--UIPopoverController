//
//  AGPopoverDetailsController.m
//  UIPopoverController (Lesson 36)
//
//  Created by Anton Gorlov on 10.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGPopoverDetailsController.h"

@implementation AGPopoverDetailsController


#pragma mark -Segue

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender { // сюда приходит segue,когда мы хотим запустить одну из каких-то связей (осущ, переход)
    
    NSLog(@"prepareForSegue %@ %@",segue.identifier, NSStringFromClass([segue.destinationViewController class])); //какой сейчас контроллер, который передается в этой segue (проверим запустив Popover (в консоле покажет ))
    
}

- (void) dealloc {

    NSLog(@"AGPopoverDetailsController deallocated");
}
@end
