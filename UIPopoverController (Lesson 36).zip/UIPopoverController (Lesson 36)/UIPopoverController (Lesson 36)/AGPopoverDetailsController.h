//
//  AGPopoverDetailsController.h
//  UIPopoverController (Lesson 36)
//
//  Created by Anton Gorlov on 10.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGPopoverDetailsController : UIViewController

@end
