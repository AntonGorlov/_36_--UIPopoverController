//
//  ViewController.m
//  UIPopoverController (Lesson 36)
//
//  Created by Anton Gorlov on 10.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGPopoverDetailsController.h"

@interface ViewController () <UIPopoverPresentationControllerDelegate>

@property(nonatomic,retain)UIPopoverPresentationController *popover;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Actions

- (IBAction)actionPressMe:(UIButton *)sender { //для UIButton нужно указывать Rect
   
    //указываем View Controller которы хотим показать
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"AGPopoverDetailsController"];
    
    //отображаем контроллер
    // on iPad, this will be a Popover
    // on iPhone, this will be an action sheet
    controller.modalPresentationStyle = UIModalPresentationPopover; //стиль
    
    [self presentViewController:controller animated:YES completion:nil];
    
    // configure the Popover presentation controller
    UIPopoverPresentationController *popController = [controller popoverPresentationController]; //создаем Popover
    popController.permittedArrowDirections = UIPopoverArrowDirectionRight; //устанавливаем стрелки
    
    popController.delegate = self;     //устанавливаем для popover delegate,чтобы мог удалятся после закрытия popover
    self.popover = popController;      //устанавливаем  popover как property (Чтобы он не удалялся как выйдем из метода)
    
    // in case we don't have a bar button as reference
    popController.sourceView = self.view; //устанавливаем на какой вьюхе появиться поповер
    popController.sourceRect = sender.frame;//устанавливаем на каком триугольнике  появиться поповер
    
    controller.preferredContentSize = CGSizeMake(250, 250); //изменяем размер контроллера
    
}

- (IBAction)actionAdd:(UIBarButtonItem *)sender {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AGPopoverDetailsController* controller = [storyboard instantiateViewControllerWithIdentifier:@"AGPopoverDetailsController"];
     controller.modalPresentationStyle = UIModalPresentationPopover; //стиль (поставь строку - popController.barButtonItem = sender;)
    [self presentViewController:controller animated:YES completion:nil]; //устанавливаем popover
    
    // configure the Popover presentation controller
    UIPopoverPresentationController *popController = [controller popoverPresentationController];
    popController.barButtonItem = sender; //какой barButtonItem нажат
    popController.permittedArrowDirections = UIPopoverArrowDirectionAny; //с какой стороны стрелочки
    
    popController.delegate = self;
   
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
       
        [self dismissViewControllerAnimated:YES completion:nil]; //через 3 сек удалиться Popover

    });
    
}

#pragma mark - UIPopoverPresentationControllerDelegate

- (void)prepareForPopoverPresentation:(UIPopoverPresentationController *)popoverPresentationController {
    
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController { //метод держит/не держит появившийся Popover (закрыть нельзя/можно)
    
    return YES;
}

- (void)popoverPresentationControllerDidDismissPopover:(UIPopoverPresentationController *)popoverPresentationController { //удаляем Popover,если удаляем через dispatch_after,то в этот метод не заходим

    self.popover = nil;
    NSLog(@"popoverPresentationControllerDidDismissPopover %@",popoverPresentationController);
}

//создаем через Storyboard с помощью Segue!  В Storyboard проще не надо писать много кода,устанавливать delegate.Для iPhone делаем Modal, для iPad делаем Popover
#pragma mark -Segue

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender { // сюда приходит segue,когда мы хотим запустить одну из каких-то связей (осущ, переход)

    NSLog(@"prepareForSegue %@ %@",segue.identifier, NSStringFromClass([segue.destinationViewController class])); //какой сейчас контроллер, который передается в этой segue (проверим запустив Popover (в консоле покажет ))
    
}

@end
