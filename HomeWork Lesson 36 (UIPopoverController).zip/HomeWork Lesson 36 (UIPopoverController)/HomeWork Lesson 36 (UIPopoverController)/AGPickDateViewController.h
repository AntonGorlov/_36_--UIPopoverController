//
//  AGPickDateViewController.h
//  HomeWork Lesson 36 (UIPopoverController)
//
//  Created by Anton Gorlov on 12.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol AGPickDateViewControllerDelegate;

@interface AGPickDateViewController : UIViewController 


@property (weak, nonatomic) id <AGPickDateViewControllerDelegate> delegate;
@property (strong, nonatomic) IBOutlet UIView *detaPickerView;
@property (strong, nonatomic) NSDate* currentDate;
@property (weak, nonatomic) IBOutlet UIDatePicker *pickDateRoller;

- (IBAction)dateBirthEnteredAction:(UIButton *)sender;


@end
@protocol AGPickDateViewControllerDelegate <NSObject>

@required

- (void)datePickDidEndEditing:(NSDate *)date;

@end
