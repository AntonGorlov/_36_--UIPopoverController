//
//  AGTableViewController.h
//  HomeWork Lesson 36 (UIPopoverController)
//
//  Created by Anton Gorlov on 12.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGTableViewController.h"


@interface AGTableViewController : UITableViewController <UIPopoverPresentationControllerDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField* firstNameField;
@property (weak, nonatomic) IBOutlet UITextField *birthDayField;

@property (strong, nonatomic) IBOutlet UITextField* surNameField;
@property (weak, nonatomic) IBOutlet UITextField *educationField;

@property (assign, nonatomic) BOOL atPresent;

@end
