//
//  AGEducationViewController.h
//  HomeWork Lesson 36 (UIPopoverController)
//
//  Created by Anton Gorlov on 15.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AGEducationViewControllerDelegate;

@interface AGEducationViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) id <AGEducationViewControllerDelegate> delegate;
@property (weak, nonatomic) IBOutlet UITableView *educationTableView;
@property (strong, nonatomic) NSString *selectedDegree;

- (IBAction)educationChooseAction:(UIButton *)sender;

@end


@protocol AGEducationViewControllerDelegate <NSObject>

@required

-(void)dataFromEducationPickerController:(NSString*)educationString;


@end