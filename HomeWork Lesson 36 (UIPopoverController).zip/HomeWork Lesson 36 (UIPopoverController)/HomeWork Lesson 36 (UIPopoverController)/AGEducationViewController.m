//
//  AGEducationViewController.m
//  HomeWork Lesson 36 (UIPopoverController)
//
//  Created by Anton Gorlov on 15.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGEducationViewController.h"

static NSString* cellIdentifier = @"educationDegreeCell";

@interface AGEducationViewController ()
@property (strong,nonatomic) NSArray *educationDegrees;

@end

@implementation AGEducationViewController

-(void) viewDidLoad {

    [super viewDidLoad];
      self.educationDegrees = [NSArray arrayWithObjects:@"trus",@"balbes",@"bivaliy",@"master",@"supermen", nil];
   //or  self.educationDegrees = @[@"trus",@"balbes",@"bivaliy"];
}


-(void)dealloc {
    
    NSLog(@"AGEducationViewController deallocated");
}


#pragma mark - UIPopoverPresentationControllerDelegate

- (void)prepareForPopoverPresentation:(UIPopoverPresentationController *)popoverPresentationController {
    
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    
    return YES;
    // Called on the delegate when the popover controller will dismiss the popover. Return NO to prevent the
    // dismissal of the view.
}

#pragma mark - Methods

- (UITableViewCellAccessoryType) accessoryTypeForCells:(UITableViewCell*) cell {

    UITableViewCellAccessoryType accessoryType = UITableViewCellAccessoryNone;
    
    if ([cell.textLabel.text isEqualToString:self.selectedDegree]) {
        
        accessoryType = UITableViewCellAccessoryCheckmark;
    }
    
    return accessoryType;
}

#pragma mark -Action

- (IBAction)educationChooseAction:(UIButton *)sender {
    
    [self.delegate dataFromEducationPickerController:self.selectedDegree];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath { //когда нажимаем на ряд ,мы выделяем его Checkmark-ой
    
    for (UITableViewCell *cell in [tableView visibleCells]) {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    
    self.selectedDegree = [self.educationDegrees objectAtIndex:indexPath.row];
    
    [tableView reloadData];

    
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

   return [self.educationDegrees count];
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    UITableViewCell *cell = [self.educationTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    cell.textLabel.text = [self.educationDegrees objectAtIndex:indexPath.row];
    cell.accessoryType = [self accessoryTypeForCells:cell];
    
    return cell;
}
@end
