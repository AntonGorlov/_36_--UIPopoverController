//
//  AGPickDateViewController.m
//  HomeWork Lesson 36 (UIPopoverController)
//
//  Created by Anton Gorlov on 12.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGPickDateViewController.h"
#import "AGTableViewController.h"

@interface AGPickDateViewController ()

@end

@implementation AGPickDateViewController


- (void) viewDidLoad {
    [super viewDidLoad];
  
  
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
   
    
    if (self.currentDate == nil) {
        [self.pickDateRoller setDate:[NSDate dateWithTimeIntervalSinceNow:0] animated:YES];
    } else {
        [self.pickDateRoller setDate:self.currentDate animated:YES];
    }
    
}

- (IBAction)dateBirthEnteredAction:(UIButton *)sender {
    
    NSLog(@"Ok is pressed %@", sender);
    self.currentDate = self.pickDateRoller.date;
    
    [self.delegate datePickDidEndEditing:self.pickDateRoller.date];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)dealloc {
    
    NSLog(@"PickDateViewController deallocated");
}


#pragma mark - UIPopoverPresentationControllerDelegate

- (void)prepareForPopoverPresentation:(UIPopoverPresentationController *)popoverPresentationController {
    
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    
    return YES;
    // Called on the delegate when the popover controller will dismiss the popover. Return NO to prevent the
    // dismissal of the view.
}

@end
