//
//  AGDetailsViewController.m
//  HomeWork Lesson 36 (UIPopoverController)
//
//  Created by Anton Gorlov on 12.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDetailsViewController.h"


@implementation AGDetailsViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissForViewController)];
    [self.view addGestureRecognizer:tap];
    
    
}

- (void) dismissForViewController {

    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void) dealloc {

    NSLog(@"AGDetailsViewController deallocated");

}



@end
