//
//  AGTableViewController.m
//  HomeWork Lesson 36 (UIPopoverController)
//
//  Created by Anton Gorlov on 12.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGTableViewController.h"
#import "AGPickDateViewController.h"
#import "AGEducationViewController.h"

@interface AGTableViewController ()  <UIPopoverPresentationControllerDelegate, UITextFieldDelegate, AGPickDateViewControllerDelegate ,AGEducationViewControllerDelegate>

@property (strong, nonatomic) UIPopoverPresentationController* popover;

@end

@implementation AGTableViewController 

typedef enum {
    
    AGFieldFirstName,
    AGFieldSurname,
    

}AGField;

typedef enum NSUInteger{
    
    AGSenderBirthDate = 2,
    AGSenderEducationDegree = 3
    
}AGSender;

- (void) viewDidLoad {
    [super viewDidLoad];
    
    [self.firstNameField becomeFirstResponder];

}

#pragma mark- Popovers

- (void) dateOfDirthPopoverFromSender:(id)sender {

    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AGPickDateViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"AGPickDateViewController"];
    
    controller.modalPresentationStyle = UIModalPresentationPopover;
    controller.delegate = self; // activate subscribe to delegate of pickdateviewcontroller
    
    [self presentViewController:controller animated:YES completion:nil];
    
    UIPopoverPresentationController *popController = [controller popoverPresentationController];
    popController.sourceView = sender;
    popController.permittedArrowDirections = UIPopoverArrowDirectionLeft;
    popController.sourceView = sender;
    popController.sourceRect = CGRectMake(0, 0, 0, 0);
    popController.delegate = self;

}

- (void) educationPopoverFromSender:(id) sender {

    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AGEducationViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"AGEducationViewController"];
    
    controller.modalPresentationStyle = UIModalPresentationPopover;
    controller.delegate = self;
    
    [self presentViewController:controller animated:YES completion:nil];
    
    UIPopoverPresentationController *popController = [controller popoverPresentationController];
    popController.sourceView = sender;
    popController.permittedArrowDirections = UIPopoverArrowDirectionLeft;
    popController.sourceView = sender;
    popController.sourceRect = CGRectMake(0, 0, 0, 0);
    popController.delegate = self;
   
}

#pragma mark- UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {

    NSLog(@"text field is pressed but only popover %@",textField);
    
    switch (textField.tag) {
        case AGSenderBirthDate:
            [self dateOfDirthPopoverFromSender:textField];
            return NO;
            break;
            
        case AGSenderEducationDegree:
            
            [self educationPopoverFromSender:textField];
            return NO;
            break;
            
            
        default:
            return YES;
            break;
    }


}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {

    
    if ([textField isEqual:self.firstNameField]) {
        
        [self.surNameField becomeFirstResponder];
        
    }
    
    if ([textField isEqual:self.surNameField]) {
        
        [self.surNameField resignFirstResponder];
        
    }
    
    return YES;

}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string { // изменяет символы в диапазоне
    
    
    
    switch (textField.tag) {
        case AGFieldFirstName:
            [self scriptNameField:textField shouldChangeCharactersInRange:range replacementString:string];
            return NO;
            break;
            
        case AGFieldSurname:
            
            [self scriptSurnameField:textField shouldChangeCharactersInRange:range replacementString:string];
            return NO;
            break;
            
        default:
            break;
    }
    
    return YES;
}


- (BOOL) scriptNameField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    //соз набор символов
    NSCharacterSet* validation = [NSCharacterSet characterSetWithCharactersInString:@"!@#$%^?&,<>""''()+-:;{}[]|/*//\\ 1234567890"];
    
    NSArray* components = [string componentsSeparatedByCharactersInSet:validation];
    
    if ([components count] > 1) {
        return NO;
    }
    
    NSString* nameResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    
    if (([nameResultString rangeOfString:@"@"].length < 1)) {
        
        self.atPresent = NO;
    }
    
    textField.text = nameResultString;
    
    return NO;
    
}

- (BOOL) scriptSurnameField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    //соз набор символов
    NSCharacterSet* validation = [NSCharacterSet characterSetWithCharactersInString:@"!№:@#$%^?&,<>""''()+-:;{}[]|/*//\\ 1234567890"];
    
    NSArray* components = [string componentsSeparatedByCharactersInSet:validation];
    
    if ([components count] > 1) {
        return NO;
    }
    
    NSString* surnameResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    
    if (([surnameResultString rangeOfString:@"@"].length < 1)) {
        
        self.atPresent = NO;
    }
    
    textField.text = surnameResultString;
    
    return NO;
    
}

#pragma mark - UIPopoverPresentationControllerDelegate

- (void)prepareForPopoverPresentation:(UIPopoverPresentationController *)popoverPresentationController {
    
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    
    return YES;
    // Called on the delegate when the popover controller will dismiss the popover. Return NO to prevent the
    // dismissal of the view.
}

# pragma mark - Mine Delegates

- (void)datePickDidEndEditing:(NSDate *)date {
    
    NSDateFormatter *dateFormater = [[NSDateFormatter alloc]init];
    [dateFormater setDateFormat:@"dd MMM yyyy"];
    self.birthDayField.text = [dateFormater stringFromDate:date];
    
    NSLog(@"%@",self.birthDayField.text);
    
}

- (void) dataFromEducationPickerController:(NSString *)educationString {
    
    self.educationField.text = educationString;
    
    NSLog(@"%@",self.educationField.text);

}

#pragma mark - Segue

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    NSLog(@"prepareForSegue %@", segue.identifier);
}

@end
